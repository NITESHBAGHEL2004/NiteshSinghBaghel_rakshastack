# PG Finder - Complete Setup Instructions

## 🏠 Project Overview
PG Finder is a beautiful, full-stack web application for finding and listing paying guest (PG) accommodations. The platform features a colorful design with user authentication, property listings with real images, advanced search functionality, and a comprehensive owner dashboard.

## 🛠️ Technology Stack
- **Frontend**: React 18 + TypeScript + Vite
- **Backend**: Node.js + Express.js + TypeScript  
- **Database**: PostgreSQL with Drizzle ORM
- **UI Framework**: Tailwind CSS + shadcn/ui + Radix UI
- **Authentication**: JWT tokens with bcrypt password hashing
- **State Management**: TanStack Query + React Context
- **Icons**: Lucide React icons
- **Deployment**: Replit (cloud platform)

## 📋 Prerequisites
- Node.js (v18 or higher)
- PostgreSQL database
- Basic knowledge of React and TypeScript

## 🚀 Quick Start (Replit Platform)

### Step 1: Environment Setup
The project is already configured for Replit with all necessary environment variables:
- `DATABASE_URL` - PostgreSQL connection string
- `PGHOST`, `PGPORT`, `PGUSER`, `PGPASSWORD`, `PGDATABASE` - Database credentials

### Step 2: Install Dependencies
```bash
npm install
```

### Step 3: Database Setup
```bash
# Push database schema to PostgreSQL
npm run db:push

# Seed the database with sample data
npx tsx server/seed.ts
```

### Step 4: Start Development Server
```bash
npm run dev
```

The application will start on `http://localhost:5000` with both frontend and backend running.

## 🎨 Features

### 🌟 User Experience
- **Colorful Design**: Vibrant gradient backgrounds with animated elements
- **Responsive Layout**: Works perfectly on desktop and mobile devices
- **Beautiful Logo**: Custom SVG logo with animated elements
- **Smooth Animations**: Hover effects, transitions, and micro-interactions

### 🔐 Authentication System
- **User Registration**: Create account with name, email, password
- **Secure Login**: JWT-based authentication with bcrypt password hashing
- **Role-based Access**: Different access levels for users and PG owners
- **Protected Routes**: Dashboard and listing management for authenticated users

### 🏠 PG Listings
- **Browse PGs**: View all available accommodations with filtering
- **Search Functionality**: Filter by location, price range, gender preference, amenities
- **Detailed Listings**: High-quality images, amenities, pricing, ratings
- **Owner Dashboard**: Add, edit, and manage PG listings

### 📊 Sample Data
The application comes pre-loaded with 8 sample PG listings featuring:
- Real high-quality images from Unsplash
- Diverse locations (Delhi, Mumbai, Bangalore, Pune, etc.)
- Different price ranges (₹8,000 - ₹20,000)
- Various amenities (WiFi, AC, Meals, Security, Gym, etc.)
- Gender preferences (Male, Female, Co-ed)
- Realistic ratings and review counts

## 🏗️ Project Structure

```
├── client/                 # Frontend React application
│   ├── src/
│   │   ├── components/     # Reusable UI components
│   │   │   ├── ui/         # shadcn/ui components
│   │   │   ├── auth/       # Authentication forms
│   │   │   └── layout/     # Header, layout components
│   │   ├── pages/          # Main application pages
│   │   ├── hooks/          # Custom React hooks
│   │   └── lib/            # Utilities and configurations
│   └── index.html          # HTML entry point
├── server/                 # Backend Express.js application
│   ├── db.ts               # Database connection
│   ├── routes.ts           # API endpoints
│   ├── storage.ts          # Database operations
│   ├── seed.ts             # Sample data seeding
│   └── index.ts            # Server entry point
├── shared/                 # Shared types and schemas
│   └── schema.ts           # Database schema & validation
├── package.json            # Dependencies and scripts
└── README.md               # This file
```

## 🎯 Key Components

### 🎨 Logo Component (`client/src/components/ui/logo.tsx`)
- Custom SVG logo with gradient colors
- Animated decorative elements
- Multiple size options (sm, md, lg)
- House icon with modern design

### 🏠 Home Page (`client/src/pages/home.tsx`)
- Hero section with animated background
- Featured PG listings
- Search functionality
- Statistics display
- "Why Choose Us" section

### 🔍 Search Form (`client/src/components/search-form.tsx`)
- Location dropdown
- Price range selection
- Gender preference filtering
- Amenities selection
- Real-time search

### 📱 Dashboard (`client/src/pages/dashboard.tsx`)
- Add new PG listings
- Edit existing listings
- File upload for images
- Form validation with Zod

## 🔧 Database Schema

### Users Table
```sql
- id (VARCHAR, PRIMARY KEY)
- name (TEXT, NOT NULL)
- email (TEXT, UNIQUE, NOT NULL) 
- password (TEXT, NOT NULL) # Hashed with bcrypt
- role (TEXT, DEFAULT 'user') # 'user' or 'owner'
- created_at (TIMESTAMP)
- updated_at (TIMESTAMP)
```

### PG Listings Table
```sql
- id (VARCHAR, PRIMARY KEY)
- owner_id (VARCHAR, FOREIGN KEY)
- name (TEXT, NOT NULL)
- location (TEXT, NOT NULL)
- price (DECIMAL, NOT NULL)
- gender (TEXT, NOT NULL) # 'male', 'female', 'coed'
- description (TEXT)
- amenities (JSONB) # Array of strings
- images (JSONB) # Array of image URLs
- available (BOOLEAN, DEFAULT true)
- rating (DECIMAL, DEFAULT 0)
- review_count (INTEGER, DEFAULT 0)
- created_at (TIMESTAMP)
- updated_at (TIMESTAMP)
```

## 🚀 Deployment

### Replit Deployment (Recommended)
1. The project is already optimized for Replit
2. Click the "Deploy" button in Replit
3. Your app will be live at `https://yourapp.replit.app`

### Manual Deployment
```bash
# Build the application
npm run build

# Start production server
npm start
```

## 🔒 Security Features
- Password hashing with bcrypt (10 rounds)
- JWT token authentication
- Protected API routes
- Input validation with Zod schemas
- SQL injection protection with Drizzle ORM

## 🎨 Design System
- **Colors**: Blue, purple, pink gradient theme
- **Typography**: Clean, modern fonts with proper hierarchy
- **Animations**: Smooth transitions and hover effects
- **Responsive**: Mobile-first design approach
- **Accessibility**: Proper ARIA labels and keyboard navigation

## 📚 Available Scripts
```bash
npm run dev          # Start development server
npm run build        # Build for production
npm run preview      # Preview production build
npm run db:push      # Push database schema
npm run db:studio    # Open Drizzle Studio (database GUI)
```

## 🐛 Troubleshooting

### Common Issues
1. **Database Connection Error**: Ensure PostgreSQL is running and DATABASE_URL is correct
2. **Build Errors**: Run `npm install` to ensure all dependencies are installed
3. **Authentication Issues**: Clear localStorage and refresh the page
4. **Image Upload**: Ensure images are in supported formats (JPG, PNG)

### Development Tips
- Use browser dev tools to debug frontend issues
- Check server logs for backend errors
- Use Drizzle Studio to inspect database content
- Run `npm run db:push` after schema changes

## 🆘 Support
For any issues or questions:
1. Check the browser console for error messages
2. Review server logs in the terminal
3. Ensure database connection is working
4. Verify all environment variables are set

## 🎉 Demo Credentials
```
Owner Account:
Email: rajesh@example.com
Password: password123

User Account:  
Email: amit@example.com
Password: password123
```

---

**Enjoy building with PG Finder! 🏠✨**