import { useParams } from "wouter";
import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Separator } from "@/components/ui/separator";
import { 
  MapPin, 
  Users, 
  IndianRupee, 
  Star, 
  Wifi, 
  Car, 
  Utensils, 
  Shield, 
  Tv, 
  Dumbbell,
  WashingMachine,
  ChefHat,
  Home as HomeIcon,
  ArrowLeft
} from "lucide-react";
import { PgListing } from "@shared/schema";
import { Link } from "wouter";

const amenityIcons = {
  WiFi: Wifi,
  AC: HomeIcon,
  Meals: Utensils,
  Security: Shield,
  Parking: Car,
  TV: Tv,
  Gym: Dumbbell,
  Laundry: WashingMachine,
  Kitchen: ChefHat,
  Balcony: HomeIcon,
};

export default function PgDetails() {
  const params = useParams();
  const pgId = params.id;

  const { data: listing, isLoading, error } = useQuery<PgListing>({
    queryKey: ["/api/pg-listings", pgId],
    queryFn: async () => {
      const response = await fetch(`/api/pg-listings/${pgId}`);
      if (!response.ok) throw new Error("Failed to fetch PG details");
      return response.json();
    },
    enabled: !!pgId,
  });

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="animate-pulse">
            <div className="bg-gray-300 h-64 rounded-lg mb-6"></div>
            <div className="bg-white p-6 rounded-lg">
              <div className="h-8 bg-gray-300 rounded mb-4"></div>
              <div className="h-4 bg-gray-300 rounded mb-2 w-1/2"></div>
              <div className="h-4 bg-gray-300 rounded mb-4 w-1/3"></div>
              <div className="grid grid-cols-2 gap-4">
                <div className="h-20 bg-gray-300 rounded"></div>
                <div className="h-20 bg-gray-300 rounded"></div>
              </div>
            </div>
          </div>
        </div>
      </div>
    );
  }

  if (error || !listing) {
    return (
      <div className="min-h-screen bg-gray-50 py-8">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <Card className="py-12">
            <CardContent>
              <h2 className="text-2xl font-bold text-gray-900 mb-4">PG Not Found</h2>
              <p className="text-gray-600 mb-6">
                The PG listing you're looking for doesn't exist or has been removed.
              </p>
              <Link href="/listings">
                <Button>Browse All PGs</Button>
              </Link>
            </CardContent>
          </Card>
        </div>
      </div>
    );
  }

  const genderLabel = listing.gender === "male" ? "Male Only" : 
                      listing.gender === "female" ? "Female Only" : "Co-ed";

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Back Button */}
        <Link href="/listings">
          <Button variant="ghost" className="mb-6">
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Listings
          </Button>
        </Link>

        {/* Main Image */}
        <div className="mb-8">
          <img
            src={listing.images?.[0] || "/placeholder-pg.jpg"}
            alt={listing.name}
            className="w-full h-64 md:h-96 object-cover rounded-2xl shadow-lg"
          />
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
          {/* Main Content */}
          <div className="lg:col-span-2 space-y-6">
            {/* Header */}
            <Card>
              <CardHeader>
                <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-3xl font-bold text-gray-900 mb-2">
                      {listing.name}
                    </CardTitle>
                    <div className="flex items-center text-gray-600 mb-4">
                      <MapPin className="h-5 w-5 mr-2" />
                      {listing.location}
                    </div>
                    <div className="flex items-center gap-4">
                      <div className="flex items-center">
                        <Star className="h-5 w-5 text-yellow-400 fill-current mr-1" />
                        <span className="font-semibold">{listing.rating}</span>
                        <span className="text-gray-600 ml-1">
                          ({listing.reviewCount} reviews)
                        </span>
                      </div>
                      <Badge variant="outline">
                        <Users className="h-4 w-4 mr-1" />
                        {genderLabel}
                      </Badge>
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-3xl font-bold text-primary flex items-center">
                      <IndianRupee className="h-8 w-8" />
                      {listing.price}
                    </div>
                    <div className="text-sm text-gray-600">per month</div>
                  </div>
                </div>
              </CardHeader>
            </Card>

            {/* Description */}
            <Card>
              <CardHeader>
                <CardTitle>About This PG</CardTitle>
              </CardHeader>
              <CardContent>
                <p className="text-gray-700 leading-relaxed">
                  {listing.description || "No description available."}
                </p>
              </CardContent>
            </Card>

            {/* Amenities */}
            <Card>
              <CardHeader>
                <CardTitle>Amenities</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                  {(listing.amenities as string[])?.map((amenity) => {
                    const IconComponent = amenityIcons[amenity as keyof typeof amenityIcons] || HomeIcon;
                    return (
                      <div key={amenity} className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg">
                        <IconComponent className="h-5 w-5 text-primary" />
                        <span className="font-medium">{amenity}</span>
                      </div>
                    );
                  })}
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Contact Card */}
            <Card className="sticky top-24">
              <CardHeader>
                <CardTitle>Contact Owner</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <Button className="w-full gradient-bg text-white hover:opacity-90">
                  Call Owner
                </Button>
                <Button variant="outline" className="w-full">
                  Send Message
                </Button>
                <Separator />
                <div className="text-sm text-gray-600">
                  <p className="mb-2">
                    <strong>Available:</strong> {listing.available ? "Yes" : "No"}
                  </p>
                  <p>
                    <strong>Listed:</strong> {new Date(listing.createdAt).toLocaleDateString()}
                  </p>
                </div>
              </CardContent>
            </Card>

            {/* Quick Info */}
            <Card>
              <CardHeader>
                <CardTitle>Quick Info</CardTitle>
              </CardHeader>
              <CardContent className="space-y-3">
                <div className="flex justify-between">
                  <span className="text-gray-600">Location:</span>
                  <span className="font-medium">{listing.location}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Gender:</span>
                  <span className="font-medium">{genderLabel}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Price:</span>
                  <span className="font-medium flex items-center">
                    <IndianRupee className="h-4 w-4" />
                    {listing.price}/month
                  </span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Rating:</span>
                  <span className="font-medium flex items-center">
                    <Star className="h-4 w-4 text-yellow-400 fill-current mr-1" />
                    {listing.rating}
                  </span>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}