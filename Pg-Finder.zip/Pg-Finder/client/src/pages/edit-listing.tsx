import { useState, useEffect } from "react";
import { useLocation, useParams } from "wouter";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Upload, Plus, X, Loader2 } from "lucide-react";
import { AMENITIES, GENDER_OPTIONS, LOCATIONS } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";
import { PgListing } from "@shared/schema";

interface FormData {
  name: string;
  location: string;
  price: string;
  gender: string;
  description: string;
  amenities: string[];
  images: string[];
  available: boolean;
}

export default function EditListing() {
  const [, setLocation] = useLocation();
  const params = useParams();
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [isLoading, setIsLoading] = useState(true);
  const [listing, setListing] = useState<PgListing | null>(null);
  const [newImageUrl, setNewImageUrl] = useState("");

  const [formData, setFormData] = useState<FormData>({
    name: "",
    location: "",
    price: "",
    gender: "",
    description: "",
    amenities: [],
    images: [],
    available: true,
  });
  const [customAmenity, setCustomAmenity] = useState("");

  // Redirect if not authenticated
  if (!isAuthenticated) {
    setLocation("/login");
    return null;
  }

  // Fetch listing data on component mount
  useEffect(() => {
    const fetchListing = async () => {
      if (!params.id) return;
      
      try {
        const token = localStorage.getItem("token");
        const response = await fetch(`/api/pg-listings/${params.id}`, {
          headers: {
            "Authorization": `Bearer ${token}`,
          },
        });

        if (!response.ok) {
          if (response.status === 404) {
            toast({
              title: "Error",
              description: "PG listing not found",
              variant: "destructive",
            });
            setLocation("/dashboard");
            return;
          }
          throw new Error("Failed to fetch listing");
        }

        const listingData: PgListing = await response.json();
        
        // Check if user is the owner
        if (listingData.ownerId !== user?.id) {
          toast({
            title: "Access Denied",
            description: "You can only edit listings that you created",
            variant: "destructive",
          });
          setLocation("/dashboard");
          return;
        }

        setListing(listingData);
        
        // Populate form with existing data
        setFormData({
          name: listingData.name,
          location: listingData.location,
          price: listingData.price.toString(),
          gender: listingData.gender,
          description: listingData.description || "",
          amenities: listingData.amenities as string[] || [],
          images: listingData.images as string[] || [],
          available: listingData.available || true,
        });
        
      } catch (error) {
       
        toast({
          title: "Error",
          description: "Failed to fetch listing details",
          variant: "destructive",
        });
        setLocation("/dashboard");
      } finally {
        setIsLoading(false);
      }
    };

    fetchListing();
  }, [params.id, user?.id, setLocation, toast]);

  const resetForm = () => {
    if (listing) {
      setFormData({
        name: listing.name,
        location: listing.location,
        price: listing.price.toString(),
        gender: listing.gender,
        description: listing.description || "",
        amenities: listing.amenities as string[] || [],
        images: listing.images as string[] || [],
        available: listing.available || true,
      });
      setCustomAmenity("");
      setNewImageUrl("");
    }
  };

  const handleInputChange = (field: keyof FormData, value: string | boolean | string[]) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleAmenityToggle = (amenity: string) => {
    setFormData(prev => ({
      ...prev,
      amenities: prev.amenities.includes(amenity)
        ? prev.amenities.filter(a => a !== amenity)
        : [...prev.amenities, amenity]
    }));
  };

  const addImageUrl = () => {
    if (newImageUrl.trim() && !formData.images.includes(newImageUrl.trim())) {
      setFormData(prev => ({
        ...prev,
        images: [...prev.images, newImageUrl.trim()]
      }));
      setNewImageUrl("");
    }
  };

  const removeImageUrl = (index: number) => {
    const newImages = formData.images.filter((_, i) => i !== index);
    setFormData(prev => ({
      ...prev,
      images: newImages
    }));
  };

  const updateImageUrl = (index: number, newUrl: string) => {
    const newImages = [...formData.images];
    newImages[index] = newUrl;
    setFormData(prev => ({
      ...prev,
      images: newImages
    }));
  };

  const addCustomAmenity = () => {
    if (customAmenity.trim() && !formData.amenities.includes(customAmenity.trim())) {
      setFormData(prev => ({
        ...prev,
        amenities: [...prev.amenities, customAmenity.trim()]
      }));
      setCustomAmenity("");
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!formData.name.trim() || !formData.location || !formData.price || !formData.gender) {
      toast({
        title: "Validation Error",
        description: "Please fill in all required fields",
        variant: "destructive",
      });
      return;
    }

    if (parseFloat(formData.price) <= 0) {
      toast({
        title: "Validation Error",
        description: "Price must be greater than 0",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const token = localStorage.getItem("token");
      const response = await fetch(`/api/pg-listings/${params.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`,
        },
        body: JSON.stringify({
          ...formData,
          price: formData.price, // Keep as string since backend expects string
          ownerId: user?.id,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json();
        throw new Error(errorData.message || "Failed to update listing");
      }

      const updatedListing = await response.json();
      
      toast({
        title: "Success!",
        description: "PG listing updated successfully",
      });

      // Redirect to dashboard after successful update
      setLocation("/dashboard");
      
    } catch (error: any) {
     
      toast({
        title: "Error",
        description: error.message || "Failed to update listing. Please try again.",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <Loader2 className="h-8 w-8 animate-spin mx-auto mb-4 text-primary" />
          <p className="text-gray-600">Loading listing details...</p>
        </div>
      </div>
    );
  }

  if (!listing) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => setLocation("/dashboard")}
            className="mb-4 text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
          <h1 className="text-3xl font-bold text-gray-900">Edit PG Listing</h1>
          <p className="text-gray-600 mt-2">Update your PG listing information</p>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Basic Information */}
            <Card>
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
                <CardDescription>Essential details about your PG</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="name">PG Name *</Label>
                  <Input
                    id="name"
                    placeholder="Enter PG name"
                    value={formData.name}
                    onChange={(e) => handleInputChange("name", e.target.value)}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="location">Location *</Label>
                  <Select value={formData.location} onValueChange={(value) => handleInputChange("location", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select location" />
                    </SelectTrigger>
                    <SelectContent>
                      {LOCATIONS.map((location) => (
                        <SelectItem key={location} value={location}>
                          {location}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="price">Monthly Rent (₹) *</Label>
                  <Input
                    id="price"
                    type="number"
                    placeholder="Enter monthly rent"
                    value={formData.price}
                    onChange={(e) => handleInputChange("price", e.target.value)}
                    min="0"
                    step="100"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="gender">Gender Preference *</Label>
                  <Select value={formData.gender} onValueChange={(value) => handleInputChange("gender", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select gender preference" />
                    </SelectTrigger>
                    <SelectContent>
                      {GENDER_OPTIONS.map((gender) => (
                        <SelectItem key={gender.value} value={gender.value}>
                          {gender.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="Describe your PG, facilities, rules, etc."
                    value={formData.description}
                    onChange={(e) => handleInputChange("description", e.target.value)}
                    rows={4}
                    maxLength={500}
                  />
                  <div className="text-sm text-gray-500 mt-1">
                    {formData.description.length}/500 characters
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="available"
                    checked={formData.available}
                    onCheckedChange={(checked) => handleInputChange("available", checked as boolean)}
                  />
                  <Label htmlFor="available">Available for booking</Label>
                </div>
              </CardContent>
            </Card>

            {/* Amenities & Images */}
            <Card>
              <CardHeader>
                <CardTitle>Amenities & Images</CardTitle>
                <CardDescription>What facilities does your PG offer?</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label>Amenities</Label>
                  <div className="grid grid-cols-2 gap-2 mt-2">
                    {AMENITIES.map((amenity) => (
                      <div key={amenity} className="flex items-center space-x-2">
                        <Checkbox
                          id={amenity}
                          checked={formData.amenities.includes(amenity)}
                          onCheckedChange={() => handleAmenityToggle(amenity)}
                        />
                        <Label htmlFor={amenity} className="text-sm">{amenity}</Label>
                      </div>
                    ))}
                  </div>
                  
                  {/* Custom Amenity Input */}
                  <div className="flex gap-2 mt-3">
                    <Input
                      placeholder="Add custom amenity"
                      value={customAmenity}
                      onChange={(e) => setCustomAmenity(e.target.value)}
                      className="flex-1"
                    />
                    <Button
                      type="button"
                      variant="outline"
                      size="sm"
                      onClick={addCustomAmenity}
                    >
                      <Plus className="h-4 w-4" />
                    </Button>
                  </div>
                </div>

                <div>
                  <Label>Images</Label>
                  <div className="space-y-2">
                    {formData.images.map((url, index) => (
                      <div key={index} className="flex items-center gap-2">
                        <Input
                          value={url}
                          onChange={(e) => updateImageUrl(index, e.target.value)}
                          placeholder="Image URL"
                        />
                        <Button
                          type="button"
                          variant="outline"
                          size="sm"
                          onClick={() => removeImageUrl(index)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                      </div>
                    ))}
                    
                    <div className="flex gap-2">
                      <Input
                        placeholder="Add new image URL"
                        value={newImageUrl}
                        onChange={(e) => setNewImageUrl(e.target.value)}
                        className="flex-1"
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="sm"
                        onClick={addImageUrl}
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Form Actions */}
          <div className="flex justify-between items-center mt-8">
            <Button
              type="button"
              variant="outline"
              onClick={resetForm}
              className="text-gray-600 hover:text-gray-900"
            >
              Reset Changes
            </Button>
            
            <div className="flex gap-4">
              <Button
                type="button"
                variant="outline"
                onClick={() => setLocation("/dashboard")}
              >
                Cancel
              </Button>
              <Button
                type="submit"
                disabled={isSubmitting}
                className="bg-primary text-white hover:bg-primary/90"
              >
                {isSubmitting ? (
                  <>
                    <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                    Updating...
                  </>
                ) : (
                  "Update Listing"
                )}
              </Button>
            </div>
          </div>
        </form>

        {/* Listing Preview */}
        <Card className="mt-8">
          <CardHeader>
            <CardTitle>Listing Preview</CardTitle>
            <CardDescription>How your listing will appear to users</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="font-medium">Name:</span>
                <span className="text-gray-600">{formData.name || "Not specified"}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Location:</span>
                <span className="text-gray-600">{formData.location || "Not specified"}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Price:</span>
                <span className="text-gray-600">₹{formData.price || "0"}/month</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Gender:</span>
                <span className="text-gray-600">{formData.gender || "Not specified"}</span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Available:</span>
                <span className={`${formData.available ? 'text-green-600' : 'text-red-600'}`}>
                  {formData.available ? "Yes" : "No"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Amenities:</span>
                <span className="text-gray-600">
                  {formData.amenities.length > 0 ? formData.amenities.join(", ") : "None specified"}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="font-medium">Images:</span>
                <span className="text-gray-600">{formData.images.length} image(s)</span>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}
