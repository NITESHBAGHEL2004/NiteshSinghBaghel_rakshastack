import { useQuery } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ArrowRight, Search, Shield, Headphones, Star, Users, Home as HomeIcon, MapPin } from "lucide-react";
import SearchForm from "@/components/search-form";
import PgCard from "@/components/pg-card";
import { PgListing } from "@shared/schema";
import { Link } from "wouter";
import { LogoText } from "@/components/ui/logo";

export default function Home() {
  const { data: featuredListings = [], isLoading } = useQuery<PgListing[]>({
    queryKey: ["/api/pg-listings/featured"],
  });

  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative gradient-bg text-white overflow-hidden">
        {/* Background decorative elements */}
        <div className="absolute inset-0 opacity-10">
          <div className="absolute top-20 left-10 w-32 h-32 rounded-full bg-white animate-pulse"></div>
          <div className="absolute top-40 right-20 w-24 h-24 rounded-full bg-yellow-300 animate-bounce"></div>
          <div className="absolute bottom-20 left-1/4 w-16 h-16 rounded-full bg-pink-300 animate-pulse"></div>
          <div className="absolute bottom-40 right-1/3 w-20 h-20 rounded-full bg-blue-300 animate-bounce"></div>
        </div>
        
        <div className="relative max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-20">
          <div className="text-center">
            <LogoText className="justify-center mb-8" />
            <h1 className="text-4xl md:text-6xl font-bold mb-6">
              Find Your Perfect <span className="text-yellow-300 animate-pulse">PG</span>
            </h1>
            <p className="text-xl md:text-2xl mb-12 text-purple-100 max-w-3xl mx-auto">
              Discover comfortable and affordable paying guest accommodations in your preferred location with 
              <span className="text-yellow-300 font-semibold"> verified listings</span> and 
              <span className="text-pink-300 font-semibold"> trusted reviews</span>
            </p>

            <SearchForm className="max-w-4xl mx-auto" />
            
            {/* Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-16 max-w-2xl mx-auto">
              <div className="text-center">
                <div className="text-3xl font-bold text-yellow-300">500+</div>
                <div className="text-sm text-purple-200">Verified PGs</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-pink-300">50k+</div>
                <div className="text-sm text-purple-200">Happy Users</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-blue-300">15+</div>
                <div className="text-sm text-purple-200">Cities</div>
              </div>
              <div className="text-center">
                <div className="text-3xl font-bold text-green-300">4.8★</div>
                <div className="text-sm text-purple-200">Rating</div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Featured PGs Section */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Featured PGs</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              Discover top-rated paying guest accommodations handpicked by our team
            </p>
          </div>

          {isLoading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="animate-pulse">
                  <div className="bg-gray-300 h-48 rounded-t-2xl"></div>
                  <div className="bg-white p-6 rounded-b-2xl">
                    <div className="h-4 bg-gray-300 rounded mb-2"></div>
                    <div className="h-4 bg-gray-300 rounded w-2/3 mb-4"></div>
                    <div className="h-8 bg-gray-300 rounded"></div>
                  </div>
                </div>
              ))}
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {featuredListings.map((listing) => (
                <PgCard key={listing.id} listing={listing} />
              ))}
            </div>
          )}

          <div className="text-center mt-12">
            <Link href="/listings">
              <Button className="gradient-bg text-white px-8 py-3 hover:opacity-90 transition-all duration-200 transform hover:scale-105">
                View All PGs
                <ArrowRight className="ml-2 h-4 w-4" />
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Why Choose Us Section */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">Why Choose PGFind?</h2>
            <p className="text-lg text-gray-600 max-w-2xl mx-auto">
              We make finding your perfect PG simple, safe, and stress-free
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 gradient-bg rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Search className="text-white h-8 w-8" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Easy Search</h3>
                <p className="text-gray-600">
                  Find PGs with our advanced search filters. Location, price, amenities - filter by what matters to you.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-green-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Shield className="text-white h-8 w-8" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">Verified Listings</h3>
                <p className="text-gray-600">
                  All our PG listings are verified for authenticity. What you see is what you get.
                </p>
              </CardContent>
            </Card>

            <Card className="text-center p-6 hover:shadow-lg transition-shadow">
              <CardContent className="pt-6">
                <div className="w-16 h-16 bg-orange-500 rounded-2xl flex items-center justify-center mx-auto mb-4">
                  <Headphones className="text-white h-8 w-8" />
                </div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">24/7 Support</h3>
                <p className="text-gray-600">
                  Our dedicated support team is available round the clock to help you with any queries.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
