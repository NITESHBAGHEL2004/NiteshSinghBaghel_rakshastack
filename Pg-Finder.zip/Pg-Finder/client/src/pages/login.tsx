import { useEffect } from "react";
import { Link, useLocation } from "wouter";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import LoginForm from "@/components/auth/login-form";
import { useAuth } from "@/lib/auth-context";
import { LogoText } from "@/components/ui/logo";

export default function Login() {
  const [, setLocation] = useLocation();
  const { isAuthenticated } = useAuth();

  useEffect(() => {
    if (isAuthenticated) {
      setLocation("/dashboard");
    }
  }, [isAuthenticated, setLocation]);

  const handleLoginSuccess = () => {
    setLocation("/dashboard");
  };

  return (
    <div className="min-h-screen relative overflow-hidden">
      {/* Background with gradient */}
      <div className="absolute inset-0 gradient-bg opacity-20"></div>
      
      {/* Decorative background elements */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-10 left-10 w-40 h-40 rounded-full bg-blue-500 animate-pulse"></div>
        <div className="absolute top-20 right-20 w-32 h-32 rounded-full bg-purple-500 animate-bounce"></div>
        <div className="absolute bottom-20 left-1/4 w-24 h-24 rounded-full bg-pink-500 animate-pulse"></div>
        <div className="absolute bottom-40 right-1/3 w-28 h-28 rounded-full bg-yellow-400 animate-bounce"></div>
      </div>
      
      <div className="relative flex items-center justify-center min-h-screen py-12 px-4 sm:px-6 lg:px-8">
        <div className="w-full max-w-md space-y-8">
          {/* Logo */}
          <div className="text-center">
            <LogoText className="justify-center mb-8" />
          </div>
          
          <Card className="w-full shadow-2xl border-0 bg-white/90 backdrop-blur-sm hover-scale">
            <CardHeader className="text-center space-y-4 pb-6">
              <CardTitle className="text-3xl font-bold bg-gradient-to-r from-blue-600 to-purple-600 bg-clip-text text-transparent">
                Welcome Back!
              </CardTitle>
              <p className="text-gray-600">Sign in to find your perfect PG</p>
            </CardHeader>
            <CardContent className="space-y-6">
              <LoginForm onSuccess={handleLoginSuccess} />
              
              <div className="text-center">
                <p className="text-gray-600">
                  Don't have an account?{" "}
                  <Link href="/register">
                    <a className="bg-gradient-to-r from-purple-600 to-pink-600 bg-clip-text text-transparent font-semibold hover:opacity-80 transition-opacity">
                      Create account
                    </a>
                  </Link>
                </p>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
