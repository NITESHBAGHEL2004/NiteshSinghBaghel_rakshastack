import { useState } from "react";
import { useLocation } from "wouter";
import { useAuth } from "@/lib/auth-context";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Checkbox } from "@/components/ui/checkbox";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { ArrowLeft, Upload, Plus, X } from "lucide-react";
import { AMENITIES, GENDER_OPTIONS, LOCATIONS } from "@/lib/types";
import { useToast } from "@/hooks/use-toast";

interface FormData {
  name: string;
  location: string;
  price: string;
  gender: string;
  description: string;
  amenities: string[];
  images: string[];
  available: boolean;
}

export default function AddListings() {
  const [, setLocation] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [imageUrls, setImageUrls] = useState<string[]>([]);
  const [newImageUrl, setNewImageUrl] = useState("");

  const [formData, setFormData] = useState<FormData>({
    name: "",
    location: "",
    price: "",
    gender: "",
    description: "",
    amenities: [],
    images: [],
    available: true,
  });
  const [customAmenity, setCustomAmenity] = useState("");

  // Redirect if not authenticated
  if (!isAuthenticated) {
    setLocation("/login");
    return null;
  }

  const resetForm = () => {
    setFormData({
      name: "",
      location: "",
      price: "",
      gender: "",
      description: "",
      amenities: [],
      images: [],
      available: true,
    });
    setCustomAmenity("");
    setImageUrls([]);
    setNewImageUrl("");
  };

  const handleInputChange = (field: keyof FormData, value: string | boolean | string[]) => {
    setFormData(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleAmenityToggle = (amenity: string) => {
    setFormData(prev => ({
      ...prev,
      amenities: prev.amenities.includes(amenity)
        ? prev.amenities.filter(a => a !== amenity)
        : [...prev.amenities, amenity]
    }));
  };

  const addImageUrl = () => {
    if (newImageUrl.trim() && !imageUrls.includes(newImageUrl.trim())) {
      setImageUrls(prev => [...prev, newImageUrl.trim()]);
      setFormData(prev => ({
        ...prev,
        images: [...prev.images, newImageUrl.trim()]
      }));
      setNewImageUrl("");
    }
  };

  const addCustomAmenity = () => {
    if (customAmenity.trim() && !formData.amenities.includes(customAmenity.trim())) {
      setFormData(prev => ({
        ...prev,
        amenities: [...prev.amenities, customAmenity.trim()]
      }));
      setCustomAmenity("");
    }
  };

  const removeImageUrl = (index: number) => {
    setImageUrls(prev => prev.filter((_, i) => i !== index));
    setFormData(prev => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index)
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    // Validation
    if (!formData.name.trim()) {
      toast({
        title: "Validation Error",
        description: "PG name is required",
        variant: "destructive",
      });
      return;
    }

    if (!formData.location) {
      toast({
        title: "Validation Error",
        description: "Please select a location",
        variant: "destructive",
      });
      return;
    }

    if (!formData.price || parseFloat(formData.price) <= 0) {
      toast({
        title: "Validation Error",
        description: "Please enter a valid price",
        variant: "destructive",
      });
      return;
    }

    if (!formData.gender) {
      toast({
        title: "Validation Error",
        description: "Please select gender preference",
        variant: "destructive",
      });
      return;
    }

    setIsSubmitting(true);

    try {
      const token = localStorage.getItem("token");
      const response = await fetch("/api/pg-listings", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`,
        },
        body: JSON.stringify({
          ...formData,
          ownerId: user?.id,
        }),
      });

      if (response.ok) {
        toast({
          title: "Success!",
          description: "PG listing created successfully",
        });
        setLocation("/dashboard");
      } else {
        const error = await response.json();
        throw new Error(error.message || "Failed to create listing");
      }
    } catch (error) {
      toast({
        title: "Error",
        description: error instanceof Error ? error.message : "Failed to create listing",
        variant: "destructive",
      });
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Header */}
        <div className="mb-8">
          <Button
            variant="ghost"
            onClick={() => setLocation("/dashboard")}
            className="mb-4 text-gray-600 hover:text-gray-900"
          >
            <ArrowLeft className="h-4 w-4 mr-2" />
            Back to Dashboard
          </Button>
          <h1 className="text-3xl font-bold text-gray-900">Add New PG Listing</h1>
          <p className="text-gray-600 mt-2">Create a new PG listing to help students find their perfect accommodation</p>
        </div>

        <form onSubmit={handleSubmit}>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
            {/* Basic Information */}
            <Card>
              <CardHeader>
                <CardTitle>Basic Information</CardTitle>
                <CardDescription>Essential details about your PG</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label htmlFor="name">PG Name *</Label>
                  <Input
                    id="name"
                    placeholder="Enter PG name"
                    value={formData.name}
                    onChange={(e) => handleInputChange("name", e.target.value)}
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="location">Location *</Label>
                  <Select value={formData.location} onValueChange={(value) => handleInputChange("location", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select location" />
                    </SelectTrigger>
                    <SelectContent>
                      {LOCATIONS.map((location) => (
                        <SelectItem key={location} value={location}>
                          {location}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="price">Monthly Rent (₹) *</Label>
                  <Input
                    id="price"
                    type="number"
                    placeholder="Enter monthly rent"
                    value={formData.price}
                    onChange={(e) => handleInputChange("price", e.target.value)}
                    min="0"
                    step="100"
                    required
                  />
                </div>

                <div>
                  <Label htmlFor="gender">Gender Preference *</Label>
                  <Select value={formData.gender} onValueChange={(value) => handleInputChange("gender", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select gender preference" />
                    </SelectTrigger>
                    <SelectContent>
                      {GENDER_OPTIONS.slice(1).map((option) => (
                        <SelectItem key={option.value} value={option.value}>
                          {option.label}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    placeholder="Describe your PG, facilities, rules, etc."
                    value={formData.description}
                    onChange={(e) => handleInputChange("description", e.target.value)}
                    rows={4}
                    maxLength={500}
                  />
                  <div className="text-xs text-gray-500 mt-1 text-right">
                    {formData.description.length}/500 characters
                  </div>
                </div>
              </CardContent>
            </Card>

            {/* Amenities & Images */}
            <Card>
              <CardHeader>
                <CardTitle>Amenities & Images</CardTitle>
                <CardDescription>What facilities does your PG offer?</CardDescription>
              </CardHeader>
              <CardContent className="space-y-6">
                <div>
                  <Label>Amenities</Label>
                  <div className="grid grid-cols-2 gap-3 mt-3">
                    {AMENITIES.map((amenity) => (
                      <div key={amenity} className="flex items-center space-x-2">
                        <Checkbox
                          id={amenity}
                          checked={formData.amenities.includes(amenity)}
                          onCheckedChange={() => handleAmenityToggle(amenity)}
                        />
                        <Label htmlFor={amenity} className="text-sm font-normal">
                          {amenity}
                        </Label>
                      </div>
                    ))}
                  </div>
                  
                  {/* Custom Amenity Input */}
                  <div className="mt-4">
                    <Label>Add Custom Amenity</Label>
                    <div className="flex gap-2 mt-2">
                      <Input
                        placeholder="Enter custom amenity"
                        value={customAmenity}
                        onChange={(e) => setCustomAmenity(e.target.value)}
                      />
                      <Button
                        type="button"
                        variant="outline"
                        onClick={addCustomAmenity}
                        disabled={!customAmenity.trim()}
                      >
                        Add
                      </Button>
                    </div>
                  </div>
                  
                  {/* Selected Amenities Display */}
                  {formData.amenities.length > 0 && (
                    <div className="mt-4">
                      <Label>Selected Amenities</Label>
                      <div className="flex flex-wrap gap-2 mt-2">
                        {formData.amenities.map((amenity, index) => (
                          <div
                            key={index}
                            className="flex items-center gap-2 bg-blue-100 text-blue-800 px-3 py-1 rounded-full text-sm"
                          >
                            <span>{amenity}</span>
                            <button
                              type="button"
                              onClick={() => handleAmenityToggle(amenity)}
                              className="text-blue-600 hover:text-blue-800"
                            >
                              <X className="h-3 w-3" />
                            </button>
                          </div>
                        ))}
                      </div>
                    </div>
                  )}
                </div>

                <div>
                  <Label>Images</Label>
                  <div className="space-y-3 mt-3">
                    <div className="flex gap-2">
                      <Input
                        placeholder="Enter image URL"
                        value={newImageUrl}
                        onChange={(e) => setNewImageUrl(e.target.value)}
                      />
                      <Button
                        type="button"
                        variant="outline"
                        size="icon"
                        onClick={addImageUrl}
                        disabled={!newImageUrl.trim()}
                      >
                        <Plus className="h-4 w-4" />
                      </Button>
                    </div>
                    
                    {imageUrls.length > 0 && (
                      <div className="space-y-2">
                        {imageUrls.map((url, index) => (
                          <div key={index} className="flex items-center gap-2 p-2 bg-gray-50 rounded-md">
                            <img
                              src={url}
                              alt={`Image ${index + 1}`}
                              className="w-12 h-12 object-cover rounded"
                              onError={(e) => {
                                e.currentTarget.style.display = 'none';
                              }}
                            />
                            <span className="flex-1 text-sm text-gray-600 truncate">{url}</span>
                            <Button
                              type="button"
                              variant="ghost"
                              size="icon"
                              onClick={() => removeImageUrl(index)}
                              className="h-6 w-6"
                            >
                              <X className="h-4 w-4" />
                            </Button>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Checkbox
                    id="available"
                    checked={formData.available}
                    onCheckedChange={(checked) => handleInputChange("available", checked as boolean)}
                  />
                  <Label htmlFor="available" className="text-sm font-normal">
                    Available for booking
                  </Label>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Listing Summary */}
          {(formData.name || formData.location || formData.price || formData.gender || formData.description || formData.amenities.length > 0) && (
            <Card className="mt-8">
              <CardHeader>
                <CardTitle>Listing Preview</CardTitle>
                <CardDescription>Preview of your PG listing</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <h4 className="font-semibold text-lg text-gray-900 mb-2">
                      {formData.name || "PG Name"}
                    </h4>
                    <p className="text-gray-600 mb-2">
                      <strong>Location:</strong> {formData.location || "Not specified"}
                    </p>
                    <p className="text-gray-600 mb-2">
                      <strong>Price:</strong> ₹{formData.price || "0"}/month
                    </p>
                    <p className="text-gray-600 mb-2">
                      <strong>Gender:</strong> {formData.gender || "Not specified"}
                    </p>
                  </div>
                  <div>
                    {formData.description && (
                      <div className="mb-2">
                        <strong className="text-gray-900">Description:</strong>
                        <p className="text-gray-600 text-sm mt-1">{formData.description}</p>
                      </div>
                    )}
                    {formData.amenities.length > 0 && (
                      <div>
                        <strong className="text-gray-900">Amenities:</strong>
                        <div className="flex flex-wrap gap-1 mt-1">
                          {formData.amenities.map((amenity, index) => (
                            <span
                              key={index}
                              className="bg-gray-100 text-gray-700 px-2 py-1 rounded text-xs"
                            >
                              {amenity}
                            </span>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                </div>
              </CardContent>
            </Card>
          )}

          {/* Action Buttons */}
          <div className="mt-8 flex justify-between">
            <Button
              type="button"
              variant="outline"
              onClick={resetForm}
              disabled={isSubmitting}
            >
              Reset Form
            </Button>
            <Button
              type="submit"
              disabled={isSubmitting}
              className="px-8 py-3 text-lg"
            >
              {isSubmitting ? "Creating..." : "Create Listing"}
            </Button>
          </div>
        </form>
      </div>
    </div>
  );
}
