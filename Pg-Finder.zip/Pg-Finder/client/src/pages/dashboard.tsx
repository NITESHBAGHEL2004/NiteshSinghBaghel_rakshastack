import { useState, useEffect } from "react";
import { useQuery, useMutation } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useToast } from "@/hooks/use-toast";
import { useAuth } from "@/lib/auth-context";
import { type PgListing } from "@shared/schema";
import { Edit, Trash2, Eye, Star, MapPin, Plus, Calendar, Users, TrendingUp, Search, Filter, MoreHorizontal, User, RefreshCw, AlertCircle } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";

export default function Dashboard() {
  const [, setLocation] = useLocation();
  const { user, isAuthenticated } = useAuth();
  const { toast } = useToast();
  const [searchTerm, setSearchTerm] = useState("");
  const [statusFilter, setStatusFilter] = useState("all");

  useEffect(() => {
    if (!isAuthenticated) {
      setLocation("/login");
    }
  }, [isAuthenticated, setLocation]);

  const { data: myListings = [], isLoading, error, refetch } = useQuery<PgListing[]>({
    queryKey: ["/api/my-listings"],
    queryFn: async () => {
    
      const token = localStorage.getItem("token");
      if (!token) {
     
        throw new Error("No authentication token");
      }
      
     
      
      const response = await fetch("/api/my-listings", {
        headers: {
          "Authorization": `Bearer ${token}`,
        },
      });
      
    
      
      if (!response.ok) {
        const errorText = await response.text();
       
        throw new Error(`Failed to fetch listings: ${response.status} ${response.statusText}`);
      }
      
      const data = await response.json();
     
      return data;
    },
    enabled: isAuthenticated && !!user?.id,
    retry: 2,
    retryDelay: 1000,
  });

  // Log any query errors
  useEffect(() => {
    if (error) {
     
      toast({
        title: "Error Loading Listings",
        description: error.message || "Failed to load your listings. Please try again.",
        variant: "destructive",
      });
    }
  }, [error, toast]);

  const deleteMutation = useMutation({
    mutationFn: async (id: string) => {
      const token = localStorage.getItem("token");
      const response = await fetch(`/api/pg-listings/${id}`, {
        method: "DELETE",
        headers: {
          "Authorization": `Bearer ${token}`,
        },
      });
      if (!response.ok) {
        throw new Error("Failed to delete listing");
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/my-listings"] });
      toast({
        title: "Success!",
        description: "Your PG listing has been deleted successfully.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete listing",
        variant: "destructive",
      });
    },
  });

  const handleDelete = (id: string) => {
   
    deleteMutation.mutate(id);
    toast({
      title: "Success!",
      description: "Your PG listing has been deleted successfully.",
    });
  };

  const toggleAvailability = async (listing: PgListing) => {
    try {
      const token = localStorage.getItem("token");
      const response = await fetch(`/api/pg-listings/${listing.id}`, {
        method: "PUT",
        headers: {
          "Content-Type": "application/json",
          "Authorization": `Bearer ${token}`,
        },
        body: JSON.stringify({
          ...listing,
          available: !listing.available,
        }),
      });

      if (!response.ok) {
        throw new Error("Failed to update listing");
      }

      queryClient.invalidateQueries({ queryKey: ["/api/my-listings"] });
      toast({
        title: "Success!",
        description: `Listing marked as ${!listing.available ? "available" : "unavailable"}`,
      });
    } catch (error: any) {
      toast({
        title: "Error",
        description: error.message || "Failed to update listing",
        variant: "destructive",
      });
    }
  };

  if (!isAuthenticated) {
    return null;
  }

  // Filter listings based on search and status
  const filteredListings = myListings.filter(listing => {
    const matchesSearch = listing.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         listing.location.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesStatus = statusFilter === "all" || 
                         (statusFilter === "available" && listing.available) ||
                         (statusFilter === "unavailable" && !listing.available);
    
    return matchesSearch && matchesStatus;
  });

  // Calculate dashboard stats
  const totalListings = myListings.length;
  const availableListings = myListings.filter(listing => listing.available).length;
  const totalValue = myListings.reduce((sum, listing) => sum + Number(listing.price), 0);
  const averageRating = myListings.length > 0 
    ? myListings.reduce((sum, listing) => sum + Number(listing.rating), 0) / myListings.length 
    : 0;


  
  // Check localStorage
  const token = localStorage.getItem("token");
  const savedUser = localStorage.getItem("user");
 

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="text-3xl font-bold text-gray-900">Dashboard</h1>
            <p className="text-gray-600 mt-2">Welcome back, {user?.name}!</p>
          </div>
          
          <Button 
            onClick={() => setLocation("/add-listings")}
            className="gradient-bg text-white hover:opacity-90"
          >
            <Plus className="h-4 w-4 mr-2" />
            Add New PG
          </Button>
        </div>

        {/* Dashboard Stats */}
        {totalListings > 0 && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Listings</p>
                    <p className="text-2xl font-bold text-gray-900">{totalListings}</p>
                  </div>
                  <div className="p-2 bg-blue-100 rounded-full">
                    <Plus className="h-6 w-6 text-blue-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Available</p>
                    <p className="text-2xl font-bold text-gray-900">{availableListings}</p>
                  </div>
                  <div className="p-2 bg-green-100 rounded-full">
                    <Users className="h-6 w-6 text-green-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Total Value</p>
                    <p className="text-2xl font-bold text-gray-900">₹{totalValue.toLocaleString()}</p>
                  </div>
                  <div className="p-2 bg-purple-100 rounded-full">
                    <TrendingUp className="h-6 w-6 text-purple-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm font-medium text-gray-600">Avg Rating</p>
                    <p className="text-2xl font-bold text-gray-900">{averageRating.toFixed(1)}</p>
                  </div>
                  <div className="p-2 bg-yellow-100 rounded-full">
                    <Star className="h-6 w-6 text-yellow-600" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Quick Actions */}
        <Card className="mb-8">
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              <Button
                onClick={() => setLocation("/listings")}
                variant="outline"
                className="h-20 flex-col gap-2"
              >
                <Eye className="h-6 w-6" />
                <span>Browse All PGs</span>
              </Button>
              
              <Button
                onClick={() => setLocation("/profile")}
                variant="outline"
                className="h-20 flex-col gap-2"
              >
                <User className="h-6 w-6" />
                <span>Manage Profile</span>
              </Button>
            </div>
          </CardContent>
        </Card>

        <Tabs defaultValue="listings" className="space-y-6">
          <TabsList>
            <TabsTrigger value="listings">
              {user?.role === "owner" ? "My Listings" : "Listings"}
            </TabsTrigger>
            <TabsTrigger value="profile">Profile</TabsTrigger>
          </TabsList>

          <TabsContent value="listings" className="space-y-6">
            <div>
              <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-4 mb-6">
                <h2 className="text-xl font-semibold text-gray-900">
                  Your PG Listings ({filteredListings.length} of {totalListings})
                </h2>
                  
                  {/* Search and Filter Controls */}
                  {totalListings > 0 && (
                    <div className="flex flex-col sm:flex-row gap-3 w-full sm:w-auto">
                      <div className="relative">
                        <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                        <Input
                          placeholder="Search listings..."
                          value={searchTerm}
                          onChange={(e) => setSearchTerm(e.target.value)}
                          className="pl-10 w-full sm:w-64"
                        />
                      </div>
                      
                      <Select value={statusFilter} onValueChange={setStatusFilter}>
                        <SelectTrigger className="w-full sm:w-40">
                          <SelectValue placeholder="Filter by status" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="all">All Status</SelectItem>
                          <SelectItem value="available">Available</SelectItem>
                          <SelectItem value="unavailable">Unavailable</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </div>

                {/* Error Display */}
                {error && (
                  <Card className="border-red-200 bg-red-50">
                    <CardContent className="p-6 text-center">
                      <div className="mx-auto w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mb-4">
                        <AlertCircle className="h-8 w-8 text-red-600" />
                      </div>
                      <h3 className="text-lg font-semibold text-red-800 mb-2">Error Loading Listings</h3>
                      <p className="text-red-600 mb-4">
                        {error.message || "Failed to load your listings. Please try again."}
                      </p>
                      <div className="flex gap-2 justify-center">
                        <Button
                          onClick={() => refetch()}
                          variant="outline"
                          className="border-red-300 text-red-700 hover:bg-red-100"
                        >
                          Retry
                        </Button>
                        <Button
                          onClick={() => window.location.reload()}
                          variant="outline"
                          className="border-red-300 text-red-700 hover:bg-red-100"
                        >
                          Reload Page
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                )}
                
                {isLoading ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {Array.from({ length: 3 }).map((_, i) => (
                      <div key={i} className="animate-pulse">
                        <div className="bg-gray-300 h-48 rounded-t-2xl"></div>
                        <div className="bg-white p-6 rounded-b-2xl">
                          <div className="h-4 bg-gray-300 rounded mb-2"></div>
                          <div className="h-4 bg-gray-300 rounded w-2/3"></div>
                        </div>
                      </div>
                    ))}
                  </div>
                ) : totalListings === 0 ? (
                  <Card className="text-center py-12">
                    <CardContent>
                      <div className="mx-auto w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                        <Plus className="h-12 w-12 text-gray-400" />
                      </div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">
                        No listings yet
                      </h3>
                      <p className="text-gray-600 mb-4">
                        Start by creating your first PG listing to attract tenants.
                      </p>
                      <Button
                        onClick={() => setLocation("/add-listings")}
                        className="gradient-bg text-white hover:opacity-90"
                      >
                        <Plus className="h-4 w-4 mr-2" />
                        Add Your First PG
                      </Button>
                    </CardContent>
                  </Card>
                ) : filteredListings.length === 0 ? (
                  <Card className="text-center py-12">
                    <CardContent>
                      <div className="mx-auto w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mb-4">
                        <Search className="h-12 w-12 text-gray-400" />
                      </div>
                      <h3 className="text-xl font-semibold text-gray-900 mb-2">No listings found</h3>
                      <p className="text-gray-600 mb-4">Try adjusting your search or filter criteria.</p>
                      <Button
                        onClick={() => {
                          setSearchTerm("");
                          setStatusFilter("all");
                        }}
                        variant="outline"
                      >
                        Clear Filters
                      </Button>
                    </CardContent>
                  </Card>
                ) : (
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                    {filteredListings.map((listing) => (
                      <Card key={listing.id} className="overflow-hidden hover:shadow-lg transition-shadow">
                        <div className="aspect-[4/3] overflow-hidden relative">
                          <img
                            src={(listing.images as string[])?.[0] || "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"}
                            alt={listing.name}
                            className="w-full h-full object-cover"
                          />
                          <div className="absolute top-2 right-2">
                            <Badge variant={listing.available ? "default" : "secondary"}>
                              {listing.available ? "Available" : "Occupied"}
                            </Badge>
                          </div>
                        </div>
                        <CardContent className="p-4">
                          <div className="flex items-center justify-between mb-2">
                            <h3 className="font-semibold text-gray-900 truncate">{listing.name}</h3>
                            <div className="flex items-center text-yellow-500">
                              <Star className="h-4 w-4 fill-current" />
                              <span className="ml-1 text-sm">{Number(listing.rating).toFixed(1)}</span>
                            </div>
                          </div>
                          
                          <p className="text-gray-600 text-sm mb-2 flex items-center">
                            <MapPin className="h-3 w-3 mr-1" />
                            {listing.location}
                          </p>
                          
                          <div className="flex items-center justify-between mb-3">
                            <span className="text-lg font-bold text-primary">
                              ₹{Number(listing.price).toLocaleString()}
                            </span>
                            {listing.ownerId === user?.id && (
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => toggleAvailability(listing)}
                                className="text-xs h-6 px-2"
                              >
                                {listing.available ? "Mark Unavailable" : "Mark Available"}
                              </Button>
                            )}
                          </div>
                          
                          <div className="flex space-x-2">
                            <Button
                              variant="outline"
                              size="sm"
                              className="flex-1"
                              onClick={() => setLocation(`/pg/${listing.id}`)}
                            >
                              <Eye className="h-3 w-3 mr-1" />
                              View
                            </Button>
                            {listing.ownerId === user?.id && (
                              <>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="flex-1"
                                  onClick={() => setLocation(`/edit-listing/${listing.id}`)}
                                >
                                  <Edit className="h-3 w-3 mr-1" />
                                  Edit
                                </Button>
                                <Button
                                  variant="outline"
                                  size="sm"
                                  className="flex-1 text-red-600 hover:text-red-700"
                                  onClick={() => handleDelete(listing.id)}
                                >
                                  <Trash2 className="h-3 w-3 mr-1" />
                                  Delete
                                </Button>
                              </>
                            )}
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                )}
              </div>
          </TabsContent>

          <TabsContent value="profile">
            <Card>
              <CardHeader>
                <CardTitle>Profile Information</CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div>
                    <label className="text-sm font-medium text-gray-700">Name</label>
                    <p className="text-gray-900">{user?.name}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Email</label>
                    <p className="text-gray-900">{user?.email}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Account Type</label>
                    <p className="text-gray-900 capitalize">{user?.role}</p>
                  </div>
                  <div>
                    <label className="text-sm font-medium text-gray-700">Member Since</label>
                    <p className="text-gray-900">{new Date().toLocaleDateString()}</p>
                  </div>
                </div>
                
                <div className="pt-4 border-t">
                  <h4 className="font-medium text-gray-900 mb-2">Quick Actions</h4>
                  <div className="flex gap-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setLocation("/add-listings")}
                    >
                      <Plus className="h-4 w-4 mr-2" />
                      Add New PG
                    </Button>
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() => setLocation("/listings")}
                    >
                      <MapPin className="h-4 w-4 mr-2" />
                      Browse All PGs
                    </Button>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
