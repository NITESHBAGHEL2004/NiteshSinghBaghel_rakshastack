export interface AuthUser {
  id: string;
  name: string;
  email: string;
  role: string;
}

export interface AuthResponse {
  user: AuthUser;
  token: string;
}

export const AMENITIES = [
  "WiFi",
  "AC",
  "Meals",
  "Security",
  "Parking",
  "TV",
  "Gym",
  "Laundry",
  "Kitchen",
  "Balcony",
] as const;

export const GENDER_OPTIONS = [
  { value: "any", label: "Any Gender" },
  { value: "male", label: "Male Only" },
  { value: "female", label: "Female Only" },
  { value: "coed", label: "Co-ed" },
];

export const PRICE_RANGES = [
  { value: "any", label: "Any Price" },
  { value: "0-10000", label: "₹0 - ₹10,000" },
  { value: "10000-15000", label: "₹10,000 - ₹15,000" },
  { value: "15000-20000", label: "₹15,000 - ₹20,000" },
  { value: "20000+", label: "₹20,000+" },
];

export const LOCATIONS = [
  "Delhi",
  "Mumbai",
  "Bangalore",
  "Pune",
  "Hyderabad",
  "Chennai",
  "Kolkata",
  "Ahmedabad",
  "Noida",
  "Gurgaon",
];
