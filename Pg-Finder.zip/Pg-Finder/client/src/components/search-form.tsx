import { useState } from "react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Search, MapPin, DollarSign, Users } from "lucide-react";
import { LOCATIONS, PRICE_RANGES, GENDER_OPTIONS } from "@/lib/types";

interface SearchFormProps {
  className?: string;
}

export default function SearchForm({ className = "" }: SearchFormProps) {
  const [, setLocation] = useLocation();
  const [filters, setFilters] = useState({
    location: "",
    priceRange: "",
    gender: "",
  });

  const handleSearch = () => {
    const searchParams = new URLSearchParams();
    
    if (filters.location) searchParams.set("location", filters.location);
    if (filters.priceRange) {
      if (filters.priceRange.includes("-")) {
        const [min, max] = filters.priceRange.split("-");
        searchParams.set("minPrice", min);
        if (max) searchParams.set("maxPrice", max);
      } else if (filters.priceRange.includes("+")) {
        searchParams.set("minPrice", filters.priceRange.replace("+", ""));
      }
    }
    if (filters.gender && filters.gender !== "any") searchParams.set("gender", filters.gender);

    setLocation(`/listings?${searchParams.toString()}`);
  };

  return (
    <div className={`bg-white rounded-2xl shadow-2xl p-6 md:p-8 ${className}`}>
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 md:gap-6">
        {/* Location */}
        <div className="relative">
          <label className="block text-gray-700 text-sm font-medium mb-2 text-left">Location</label>
          <div className="relative">
            <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Select value={filters.location} onValueChange={(value) => setFilters({ ...filters, location: value })}>
              <SelectTrigger className="pl-10">
                <SelectValue placeholder="Select Location" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">All Locations</SelectItem>
                {LOCATIONS.map((location) => (
                  <SelectItem key={location} value={location}>
                    {location}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Price Range */}
        <div>
          <label className="block text-gray-700 text-sm font-medium mb-2 text-left">Price Range</label>
          <div className="relative">
            <DollarSign className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Select value={filters.priceRange} onValueChange={(value) => setFilters({ ...filters, priceRange: value })}>
              <SelectTrigger className="pl-10">
                <SelectValue placeholder="Any Price" />
              </SelectTrigger>
              <SelectContent>
                {PRICE_RANGES.map((range) => (
                  <SelectItem key={range.value} value={range.value}>
                    {range.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Gender */}
        <div>
          <label className="block text-gray-700 text-sm font-medium mb-2 text-left">Gender</label>
          <div className="relative">
            <Users className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
            <Select value={filters.gender} onValueChange={(value) => setFilters({ ...filters, gender: value })}>
              <SelectTrigger className="pl-10">
                <SelectValue placeholder="Any Gender" />
              </SelectTrigger>
              <SelectContent>
                {GENDER_OPTIONS.map((option) => (
                  <SelectItem key={option.value} value={option.value}>
                    {option.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        {/* Search Button */}
        <div className="flex items-end">
          <Button 
            onClick={handleSearch}
            className="w-full gradient-bg text-white hover:opacity-90 transition-all duration-200 transform hover:scale-105"
          >
            <Search className="h-4 w-4 mr-2" />
            Search PGs
          </Button>
        </div>
      </div>
    </div>
  );
}
