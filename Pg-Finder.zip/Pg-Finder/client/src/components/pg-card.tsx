import { Link } from "wouter";
import { Card, CardContent } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { MapPin, Star, Wifi, Snowflake, Utensils, Shield, Car, Tv } from "lucide-react";
import { PgListing } from "@shared/schema";

interface PgCardProps {
  listing: PgListing;
}

const amenityIcons: Record<string, any> = {
  WiFi: Wifi,
  AC: Snowflake,
  Meals: Utensils,
  Security: Shield,
  Parking: Car,
  TV: Tv,
};

export default function PgCard({ listing }: PgCardProps) {
  const displayAmenities = (listing.amenities as string[]).slice(0, 3);
  const defaultImage = "https://images.unsplash.com/photo-1545324418-cc1a3fa10c00?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600";
  const image = (listing.images as string[])?.[0] || defaultImage;

  return (
    <Card className="overflow-hidden hover-scale cursor-pointer">
      <div className="aspect-[4/3] overflow-hidden">
        <img 
          src={image} 
          alt={listing.name}
          className="w-full h-full object-cover"
        />
      </div>
      <CardContent className="p-6">
        <div className="flex items-center justify-between mb-2">
          <h3 className="text-xl font-semibold text-gray-900 truncate">{listing.name}</h3>
          <div className="flex items-center text-yellow-500">
            <Star className="h-4 w-4 fill-current" />
            <span className="ml-1 text-sm font-medium text-gray-700">
              {Number(listing.rating).toFixed(1)}
            </span>
          </div>
        </div>
        
        <p className="text-gray-600 mb-4 flex items-center">
          <MapPin className="h-4 w-4 text-red-500 mr-2" />
          <span className="truncate">{listing.location}</span>
        </p>
        
        <div className="flex items-center justify-between mb-4">
          <div className="text-2xl font-bold text-primary">
            ₹{Number(listing.price).toLocaleString()}
            <span className="text-sm font-normal text-gray-500">/month</span>
          </div>
          <Badge variant={listing.available ? "default" : "secondary"}>
            {listing.available ? "Available" : "Occupied"}
          </Badge>
        </div>
        
        <div className="flex flex-wrap gap-2 mb-4">
          {displayAmenities.map((amenity) => {
            const IconComponent = amenityIcons[amenity];
            return (
              <Badge key={amenity} variant="outline" className="text-xs">
                {IconComponent && <IconComponent className="h-3 w-3 mr-1" />}
                {amenity}
              </Badge>
            );
          })}
        </div>
        
        <Link href={`/pg/${listing.id}`}>
          <Button variant="outline" className="w-full hover:bg-primary hover:text-primary-foreground">
            View Details
          </Button>
        </Link>
      </CardContent>
    </Card>
  );
}
