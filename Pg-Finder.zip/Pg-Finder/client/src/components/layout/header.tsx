import { useState } from "react";
import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { Menu, LogOut, User, Home, List, Plus } from "lucide-react";
import { useAuth } from "@/lib/auth-context";
import { Logo } from "@/components/ui/logo";

export default function Header() {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();
  const { user, logout, isAuthenticated } = useAuth();

  const handleLogout = () => {
    logout();
    setIsOpen(false);
  };

  const navigationItems = [
    { href: "/", label: "Home", icon: Home },
    { href: "/listings", label: "Browse PGs", icon: List },
  ];

  const NavItems = ({ mobile = false }) => (
    <>
      {navigationItems.map((item) => (
        <Link 
          key={item.href} 
          href={item.href}
          className={`${
            mobile ? "flex items-center gap-2 py-2" : ""
          } text-gray-700 hover:text-primary font-medium transition-colors duration-200 ${
            location === item.href ? "text-primary" : ""
          }`}
          onClick={() => mobile && setIsOpen(false)}
        >
          {mobile && <item.icon className="h-4 w-4" />}
          {item.label}
        </Link>
      ))}
    </>
  );

  return (
    <header className="bg-white shadow-lg sticky top-0 z-50">
      <nav className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between items-center h-16">
          {/* Logo */}
          <Link 
            href="/"
            className="flex items-center space-x-2 hover:opacity-80 transition-opacity"
          >
            <Logo size="md" />
            <div className="flex flex-col">
              <span className="text-xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                PG Finder
              </span>
              <span className="text-xs text-gray-500 -mt-1">Find Your Perfect Stay</span>
            </div>
          </Link>

          {/* Desktop Navigation */}
          <div className="hidden md:flex items-center space-x-8">
            <NavItems />
          </div>

          {/* Desktop Auth Buttons */}
          <div className="hidden md:flex items-center space-x-4">
            {isAuthenticated ? (
              <>
                                <Link href="/add-listings">
                  <Button variant="ghost" className="text-gray-700 hover:text-primary">
                    <span className="text-2xl">+</span>
                    Add PG Listing
                  </Button>
                </Link>
                <Link href="/dashboard">
                  <Button variant="ghost" className="text-gray-700 hover:text-primary">
                    <User className="h-4 w-4 mr-2" />
                    Dashboard
                  </Button>
                </Link>
                <Button variant="ghost" onClick={handleLogout} className="text-gray-700 hover:text-primary">
                  <LogOut className="h-4 w-4 mr-2" />
                  Logout
                </Button>
              </>
            ) : (
              <>
                <Link href="/login">
                  <Button variant="ghost" className="text-gray-700 hover:text-primary">
                    Login
                  </Button>
                </Link>
                <Link href="/register">
                  <Button className="gradient-bg text-white hover:opacity-90">
                    Sign Up
                  </Button>
                </Link>
              </>
            )}
          </div>

          {/* Mobile Menu Button */}
          <Sheet open={isOpen} onOpenChange={setIsOpen}>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" className="md:hidden">
                <Menu className="h-6 w-6" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[400px]">
              <div className="flex flex-col space-y-6 mt-6">
                <NavItems mobile />
                
                {isAuthenticated ? (
                  <>
                    <hr className="my-4" />
                                        <Link 
                      href="/add-listings"
                      className="flex items-center gap-2 py-2 text-gray-700 hover:text-primary"
                      onClick={() => setIsOpen(false)}
                    >
                      <Plus className="h-4 w-4" />
                      Add PG Listing
                    </Link>
                    <Link 
                      href="/dashboard"
                      className="flex items-center gap-2 py-2 text-gray-700 hover:text-primary"
                      onClick={() => setIsOpen(false)}
                    >
                      <User className="h-4 w-4" />
                      Dashboard
                    </Link>
                    <button
                      onClick={handleLogout}
                      className="flex items-center gap-2 py-2 text-gray-700 hover:text-primary text-left"
                    >
                      <LogOut className="h-4 w-4" />
                      Logout
                    </button>
                  </>
                ) : (
                  <>
                    <hr className="my-4" />
                    <Link 
                      href="/login"
                      className="flex items-center gap-2 py-2 text-gray-700 hover:text-primary"
                      onClick={() => setIsOpen(false)}
                    >
                      Login
                    </Link>
                    <Link href="/register">
                      <Button className="gradient-bg text-white" onClick={() => setIsOpen(false)}>
                        Sign Up
                      </Button>
                    </Link>
                  </>
                )}
              </div>
            </SheetContent>
          </Sheet>
        </div>
      </nav>
    </header>
  );
}
