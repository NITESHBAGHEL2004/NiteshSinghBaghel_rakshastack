interface LogoProps {
  className?: string;
  size?: "sm" | "md" | "lg";
}

export function Logo({ className = "", size = "md" }: LogoProps) {
  const sizeClasses = {
    sm: "w-8 h-8",
    md: "w-12 h-12", 
    lg: "w-16 h-16"
  };

  return (
    <div className={`${sizeClasses[size]} ${className}`}>
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
      >
        {/* Background circle with gradient */}
        <defs>
          <linearGradient id="logoGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#3B82F6" />
            <stop offset="50%" stopColor="#8B5CF6" />
            <stop offset="100%" stopColor="#EC4899" />
          </linearGradient>
          <linearGradient id="houseGradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#FFFFFF" />
            <stop offset="100%" stopColor="#F1F5F9" />
          </linearGradient>
        </defs>
        
        {/* Main circle background */}
        <circle
          cx="50"
          cy="50"
          r="45"
          fill="url(#logoGradient)"
          className="drop-shadow-lg"
        />
        
        {/* House icon */}
        <g transform="translate(25, 25) scale(0.5)">
          {/* House base */}
          <rect
            x="15"
            y="45"
            width="70"
            height="45"
            fill="url(#houseGradient)"
            stroke="#1E293B"
            strokeWidth="2"
            rx="4"
          />
          
          {/* House roof */}
          <path
            d="M10 45 L50 15 L90 45 L85 45 L50 25 L15 45 Z"
            fill="#1E293B"
          />
          
          {/* Door */}
          <rect
            x="42"
            y="65"
            width="16"
            height="25"
            fill="#3B82F6"
            rx="2"
          />
          
          {/* Door handle */}
          <circle cx="54" cy="77" r="1.5" fill="#1E293B" />
          
          {/* Windows */}
          <rect
            x="25"
            y="55"
            width="12"
            height="12"
            fill="#60A5FA"
            rx="1"
          />
          <rect
            x="63"
            y="55"
            width="12"
            height="12"
            fill="#60A5FA"
            rx="1"
          />
          
          {/* Window crosses */}
          <line x1="31" y1="55" x2="31" y2="67" stroke="#1E293B" strokeWidth="1"/>
          <line x1="25" y1="61" x2="37" y2="61" stroke="#1E293B" strokeWidth="1"/>
          <line x1="69" y1="55" x2="69" y2="67" stroke="#1E293B" strokeWidth="1"/>
          <line x1="63" y1="61" x2="75" y2="61" stroke="#1E293B" strokeWidth="1"/>
        </g>
        
        {/* Decorative stars */}
        <g className="animate-pulse">
          <path
            d="M20 20 L22 16 L24 20 L28 18 L26 22 L30 24 L26 26 L28 30 L24 28 L22 32 L20 28 L16 30 L18 26 L14 24 L18 22 L16 18 Z"
            fill="#FBBF24"
            opacity="0.8"
          />
          <path
            d="M80 25 L81 23 L82 25 L84 24 L83 26 L85 27 L83 28 L84 30 L82 29 L81 31 L80 29 L78 30 L79 28 L77 27 L79 26 L78 24 Z"
            fill="#F472B6"
            opacity="0.8"
          />
        </g>
      </svg>
    </div>
  );
}

export function LogoText({ className = "" }: { className?: string }) {
  return (
    <div className={`flex items-center space-x-3 ${className}`}>
      <Logo size="lg" />
      <div className="flex flex-col">
        <span className="text-2xl font-bold bg-gradient-to-r from-blue-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
          PG Finder
        </span>
        <span className="text-sm text-gray-600 dark:text-gray-400 -mt-1">
          Find Your Perfect Stay
        </span>
      </div>
    </div>
  );
}