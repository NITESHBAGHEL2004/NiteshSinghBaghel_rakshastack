import { db } from "./db";
import { users, pgListings } from "@shared/schema";
import { eq } from "drizzle-orm";

async function testDatabase() {
  try {
    console.log("🔍 Testing database connection...");
    
    // Test 1: Check if we can connect to the database
    console.log("📡 Testing basic connection...");
    const testQuery = await db.select({ count: sql`1` }).from(users);
    console.log("✅ Basic connection successful:", testQuery);
    
    // Test 2: Check if users table exists and has data
    console.log("👥 Checking users table...");
    const allUsers = await db.select().from(users);
    console.log("✅ Users found:", allUsers.length);
    console.log("👤 Users:", allUsers.map(u => ({ id: u.id, name: u.name, email: u.email, role: u.role })));
    
    // Test 3: Check if pg_listings table exists and has data
    console.log("🏠 Checking pg_listings table...");
    const allListings = await db.select().from(pgListings);
    console.log("✅ Listings found:", allListings.length);
    console.log("📋 Listings:", allListings.map(l => ({ id: l.id, name: l.name, ownerId: l.ownerId, location: l.location })));
    
    // Test 4: Check specific user listings
    if (allUsers.length > 0) {
      const firstUser = allUsers[0];
      console.log(`🔍 Checking listings for user: ${firstUser.name} (${firstUser.id})`);
      
      const userListings = await db.select().from(pgListings).where(eq(pgListings.ownerId, firstUser.id));
      console.log(`✅ User listings found: ${userListings.length}`);
      console.log("📋 User listings:", userListings.map(l => ({ id: l.id, name: l.name, ownerId: l.ownerId })));
    }
    
    // Test 5: Check if there are any orphaned listings (without valid ownerId)
    console.log("🔍 Checking for orphaned listings...");
    const orphanedListings = allListings.filter(listing => 
      !allUsers.some(user => user.id === listing.ownerId)
    );
    console.log("⚠️ Orphaned listings:", orphanedListings.length);
    if (orphanedListings.length > 0) {
      console.log("📋 Orphaned listings:", orphanedListings.map(l => ({ id: l.id, name: l.name, ownerId: l.ownerId })));
    }
    
    console.log("✅ Database test completed successfully!");
    
  } catch (error) {
    console.error("❌ Database test failed:", error);
    throw error;
  }
}

// Import sql function
import { sql } from "drizzle-orm";

// Run the test
testDatabase().then(() => {
  console.log("🎉 All tests passed!");
  process.exit(0);
}).catch((error) => {
  console.error("💥 Test failed:", error);
  process.exit(1);
});
