import {
  users,
  pgListings,
  type User,
  type InsertUser,
  type UpdateUser,
  type PgListing,
  type InsertPgListing,
  type SearchFilters,
} from "@shared/schema";
import { db } from "./db";
import { eq, and, gte, lte, ilike, sql } from "drizzle-orm";

export interface IStorage {
  // User operations
  getUser(id: string): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  updateUser(id: string, user: UpdateUser): Promise<User>;

  // PG Listing operations
  getAllPgListings(filters?: SearchFilters): Promise<{ listings: PgListing[], total: number, page: number, totalPages: number }>;
  getPgListingById(id: string): Promise<PgListing | undefined>;
  createPgListing(listing: InsertPgListing): Promise<PgListing>;
  updatePgListing(id: string, listing: Partial<InsertPgListing>): Promise<PgListing>;
  deletePgListing(id: string): Promise<void>;
  getPgListingsByOwner(ownerId: string): Promise<PgListing[]>;
  getFeaturedPgListings(): Promise<PgListing[]>;
}

export class DatabaseStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user;
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    const [user] = await db.select().from(users).where(eq(users.email, email));
    return user;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async updateUser(id: string, updateData: UpdateUser): Promise<User> {
    const [user] = await db
      .update(users)
      .set({ ...updateData, updatedAt: new Date() })
      .where(eq(users.id, id))
      .returning();
    return user;
  }

  async getAllPgListings(filters?: SearchFilters): Promise<{ listings: PgListing[], total: number, page: number, totalPages: number }> {
    let countQuery = db.select({ count: sql<number>`count(*)` }).from(pgListings);
    let dataQuery = db.select().from(pgListings);
    
    const conditions = [];
    
    if (filters?.location) {
      conditions.push(ilike(pgListings.location, `%${filters.location}%`));
    }
    
    if (filters?.minPrice) {
      conditions.push(gte(pgListings.price, filters.minPrice.toString()));
    }
    
    if (filters?.maxPrice) {
      conditions.push(lte(pgListings.price, filters.maxPrice.toString()));
    }
    
    if (filters?.gender && filters.gender !== "any") {
      conditions.push(eq(pgListings.gender, filters.gender));
    }
    
    conditions.push(eq(pgListings.available, true));
    
    if (conditions.length > 0) {
      countQuery = countQuery.where(and(...conditions)) as any;
      dataQuery = dataQuery.where(and(...conditions)) as any;
    }
    
    const page = filters?.page || 1;
    const limit = filters?.limit || 12;
    const offset = (page - 1) * limit;
    
    const [countResult] = await countQuery;
    const total = countResult.count;
    const totalPages = Math.ceil(total / limit);
    
    const listings = await dataQuery
      .orderBy(sql`${pgListings.createdAt} DESC`)
      .limit(limit)
      .offset(offset);
    
    return {
      listings,
      total,
      page,
      totalPages
    };
  }

  async getPgListingById(id: string): Promise<PgListing | undefined> {
    const [listing] = await db.select().from(pgListings).where(eq(pgListings.id, id));
    return listing;
  }

  async createPgListing(insertListing: InsertPgListing): Promise<PgListing> {
    const [listing] = await db
      .insert(pgListings)
      .values([insertListing])
      .returning();
    return listing;
  }

  async updatePgListing(id: string, updateData: Partial<InsertPgListing>): Promise<PgListing> {
    const [listing] = await db
      .update(pgListings)
      .set({ ...updateData, updatedAt: new Date() } as any)
      .where(eq(pgListings.id, id))
      .returning();
    return listing;
  }

  async deletePgListing(id: string): Promise<void> {
    await db.delete(pgListings).where(eq(pgListings.id, id));
  }

  async getPgListingsByOwner(ownerId: string): Promise<PgListing[]> {
    console.log("🔍 Database: Fetching listings for owner:", ownerId);
    console.log("🔍 Database: ownerId type:", typeof ownerId);
    console.log("🔍 Database: ownerId value:", ownerId);
    
    try {
      // First, let's check if the owner exists
      const owner = await db.select().from(users).where(eq(users.id, ownerId));
      console.log("🔍 Database: Owner check result:", owner);
      
      // Then get the listings
      const listings = await db.select().from(pgListings).where(eq(pgListings.ownerId, ownerId));
      console.log("✅ Database: Found", listings.length, "listings");
      console.log("🔍 Database: Listings data:", listings);
      
      // Also check all listings to see what's in the database
      const allListings = await db.select().from(pgListings);
      console.log("🔍 Database: Total listings in database:", allListings.length);
      console.log("🔍 Database: All listings ownerIds:", allListings.map(l => ({ id: l.id, name: l.name, ownerId: l.ownerId })));
      
      return listings;
    } catch (error) {
      console.error("❌ Database error in getPgListingsByOwner:", error);
      throw error;
    }
  }

  async getFeaturedPgListings(): Promise<PgListing[]> {
    return db
      .select()
      .from(pgListings)
      .where(eq(pgListings.available, true))
      .orderBy(sql`${pgListings.rating} DESC`)
      .limit(6);
  }
}

export const storage = new DatabaseStorage();
