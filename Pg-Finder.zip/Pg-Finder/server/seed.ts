import { db } from "./db";
import { users, pgListings } from "@shared/schema";
import { eq } from "drizzle-orm";
import bcrypt from "bcrypt";

const sampleUsers = [
  {
    name: "Rajesh Kumar",
    email: "rajesh@example.com", 
    password: "password123",
    role: "owner" as const
  },
  {
    name: "Priya Sharma",
    email: "priya@example.com",
    password: "password123", 
    role: "owner" as const
  },
  {
    name: "Amit Singh",
    email: "amit@example.com",
    password: "password123",
    role: "user" as const
  }
];

const samplePGListings = [
  {
    name: "Sunrise PG for Women",
    location: "Delhi",
    price: "12000",
    gender: "female",
    description: "A comfortable and safe PG accommodation for working women. Located in a prime area with easy access to metro stations and offices.",
    amenities: ["WiFi", "AC", "Meals", "Security", "Laundry"],
    images: ["https://images.unsplash.com/photo-1556020685-ae41abfc9365?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"],
    available: true,
    rating: "4.5",
    reviewCount: 28
  },
  {
    name: "Modern Boys Hostel",
    location: "Bangalore",
    price: "15000",
    gender: "male",
    description: "A modern hostel with all amenities for working professionals. Close to IT parks and tech companies.",
    amenities: ["WiFi", "AC", "Gym", "Security", "Parking", "Kitchen"],
    images: ["https://images.unsplash.com/photo-1555854877-bab0e564b8d5?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"],
    available: true,
    rating: "4.2",
    reviewCount: 15
  },
  {
    name: "Green Valley Co-ed PG",
    location: "Mumbai",
    price: "18000",
    gender: "coed",
    description: "Premium co-ed accommodation with rooftop garden and recreational facilities. Perfect for young professionals.",
    amenities: ["WiFi", "AC", "Meals", "Security", "TV", "Balcony", "Gym"],
    images: ["https://images.unsplash.com/photo-1522708323590-d24dbb6b0267?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"],
    available: true,
    rating: "4.8",
    reviewCount: 42
  },
  {
    name: "Budget Stay for Students",
    location: "Pune",
    price: "8000",
    gender: "male",
    description: "Affordable accommodation for students with basic amenities. Close to universities and colleges.",
    amenities: ["WiFi", "Meals", "Security", "Laundry"],
    images: ["https://images.unsplash.com/photo-1586023492125-27b2c045efd7?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"],
    available: true,
    rating: "3.9",
    reviewCount: 12
  },
  {
    name: "Executive Women's Residence",
    location: "Hyderabad",
    price: "16000",
    gender: "female",
    description: "Premium accommodation for working women with housekeeping and concierge services.",
    amenities: ["WiFi", "AC", "Meals", "Security", "Parking", "TV", "Gym"],
    images: ["https://images.unsplash.com/photo-1484154218962-a197022b5858?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"],
    available: true,
    rating: "4.6",
    reviewCount: 35
  },
  {
    name: "Tech Hub Co-living",
    location: "Chennai",
    price: "20000",
    gender: "coed",
    description: "Modern co-living space with smart home features and community events for tech professionals.",
    amenities: ["WiFi", "AC", "Security", "Parking", "TV", "Gym", "Kitchen"],
    images: ["https://images.unsplash.com/photo-1502672260266-1c1ef2d93688?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"],
    available: true,
    rating: "4.7",
    reviewCount: 23
  },
  {
    name: "Comfort Zone PG",
    location: "Kolkata",
    price: "10000",
    gender: "female",
    description: "Homely atmosphere with traditional Bengali meals and warm hospitality.",
    amenities: ["WiFi", "Meals", "Security", "TV", "Laundry"],
    images: ["https://images.unsplash.com/photo-1571896349842-33c89424de2d?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"],
    available: true,
    rating: "4.3",
    reviewCount: 18
  },
  {
    name: "Premium Male Hostel",
    location: "Ahmedabad",
    price: "13000",
    gender: "male",
    description: "Well-furnished rooms with attached bathrooms and 24/7 power backup.",
    amenities: ["WiFi", "AC", "Security", "Parking", "TV"],
    images: ["https://images.unsplash.com/photo-1564013799919-ab600027ffc6?ixlib=rb-4.0.3&auto=format&fit=crop&w=800&h=600"],
    available: true,
    rating: "4.1",
    reviewCount: 26
  }
];

export async function seedDatabase() {
  try {
    console.log("Starting database seeding...");
    
    // Create users
    const hashedPassword = await bcrypt.hash("password123", 10);
    
    for (const userData of sampleUsers) {
      const existingUser = await db.select().from(users).where(eq(users.email, userData.email));
      
      if (existingUser.length === 0) {
        await db.insert(users).values({
          name: userData.name,
          email: userData.email,
          password: hashedPassword,
          role: userData.role
        });
        console.log(`Created user: ${userData.name}`);
      }
    }
    
    // Get owner users for PG listings
    const ownerUsers = await db.select().from(users).where(eq(users.role, "owner"));
    
    if (ownerUsers.length === 0) {
      console.log("No owner users found, skipping PG listings creation");
      return;
    }
    
    // Create PG listings
    for (let i = 0; i < samplePGListings.length; i++) {
      const listingData = samplePGListings[i];
      const owner = ownerUsers[i % ownerUsers.length]; // Rotate through owners
      
      const existingListing = await db.select().from(pgListings).where(eq(pgListings.name, listingData.name));
      
      if (existingListing.length === 0) {
        await db.insert(pgListings).values({
          ...listingData,
          ownerId: owner.id
        });
        console.log(`Created PG listing: ${listingData.name}`);
      }
    }
    
    console.log("Database seeding completed!");
    
  } catch (error) {
    console.error("Error seeding database:", error);
  }
}

// Run seeding when this file is executed directly
seedDatabase().then(() => process.exit(0));